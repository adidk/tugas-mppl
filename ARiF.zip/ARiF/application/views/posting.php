<div class="container">
    <div class="row">
        <div class="col-lg-3"></div>
        <div class="col-lg-6">
            <?= form_error('menu', '<div class="alert alert-danger" role="alert">', '</div>'); ?>
            <?= form_open_multipart('posting'); ?>
            <div class="form-group">
                <label for="menu_name">Nama Menu</label>
                <input type="text" name="menu_name" id="menu_name" class="form-control" placeholder="Menu Apa ini?">
                <?php echo form_error('menu_name', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
            <div class="form-group">
                <label for="caption">Caption</label>
                <input type="text" name="caption" id="caption" class="form-control" placeholder="Deskripsi Menu?">
                <?php echo form_error('caption', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
            <div class="custom-file">
                <input type="file" class="custom-file-input" id="image" name="image">
                <label class="custom-file-label" for="image">Choose file</label>
                <?php echo form_error('caption', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
            <button type="submit" class="btn btn-primary mt-5">Posting</button>
            </form>
        </div>
        <div class="col-lg-3"></div>
    </div>
</div>