<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="utf-8">
    <title><?= $judul ?></title>

    <!-- mobile responsive meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- ** Plugins Needed for the Project ** -->
    <!-- Bootstrap -->
    <link rel="stylesheet" href="<?= base_url() ?>assets/plugins/bootstrap/bootstrap.min.css">
    <!-- slick slider -->
    <link rel="stylesheet" href="<?= base_url() ?>assets/plugins/slick/slick.css">
    <!-- themefy-icon -->
    <link rel="stylesheet" href="<?= base_url() ?>assets/plugins/themify-icons/themify-icons.css">

    <!-- Main Stylesheet -->
    <link href="<?= base_url() ?>assets/css/style.css" rel="stylesheet">

    <!--Favicon-->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon">

</head>

<div class="container">
    <div class="row">
        <div class="col-lg-3"></div>
        <div class="col-lg-6">
            <h3 class="text-center mt-3 mb-3">Log-in</h3>
            <?= $this->session->flashdata('message') ?>
            <form class="user" method="post" action="<?= base_url() ?>auth/login">
                <div class="form-group">
                    <label class="font-weight-bold" for="email">Email</label>
                    <input type="text" class="form-control" id="email" name="email" placeholder="Email">
                    <?php echo form_error('email', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
                <div class="form-group">
                    <label class="font-weight-bold" for="password">Password</label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Password">
                    <?php echo form_error('password', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
                <button type="submit" class="btn btn-primary">Log-in</button>
            </form>
            <p>Belum punya account? <a href="<?= base_url() ?>auth/register">Register</a></p>
        </div>
        <div class="col-lg-3"></div>
    </div>
</div>

<body>

    <!-- jQuery -->
    <script src="<?= base_url() ?>assets/plugins/jQuery/jquery.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="<?= base_url() ?>assets/plugins/bootstrap/bootstrap.min.js"></script>
    <!-- slick slider -->
    <script src="<?= base_url() ?>assets/plugins/slick/slick.min.js"></script>
    <!-- masonry -->
    <script src="<?= base_url() ?>assets/plugins/masonry/masonry.js"></script>
    <!-- instafeed -->
    <script src="<?= base_url() ?>assets/plugins/instafeed/instafeed.min.js"></script>
    <!-- smooth scroll -->
    <script src="<?= base_url() ?>assets/plugins/smooth-scroll/smooth-scroll.js"></script>
    <!-- headroom -->
    <script src="<?= base_url() ?>assets/plugins/headroom/headroom.js"></script>
    <!-- reading time -->
    <script src="<?= base_url() ?>assets/plugins/reading-time/readingTime.min.js"></script>

    <!-- Main Script -->
    <script src="<?= base_url() ?>assets/js/script.js"></script>

</body>

</html>