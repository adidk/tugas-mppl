<footer>
    <div class="section">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6 mb-4 mb-md-0">
                    <a href="index.html">ARiF | Food Review</a>
                </div>
                <div class="col-md-3 col-sm-6 mb-4 mb-md-0">
                    <ul class="list-unstyled">
                        <li class="font-secondary text-dark">Purwokerto</li>
                        <li class="font-secondary text-dark">Central Java, Indonesia</li>
                    </ul>
                </div>
                <div class="col-md-3 col-sm-6 mb-4 mb-md-0">
                    <ul class="list-unstyled">
                        <li class="font-secondary text-dark">Mail: masadikurniawandwi@gmail.com</li>
                    </ul>
                </div>
                <div class="col-md-3 col-sm-6 mb-4 mb-md-0">
                    <span class="font-secondary text-dark mr-3">Follow</span>
                    <ul class="list-inline d-inline-block">
                        <li class="list-inline-item"><a href="#" class="text-dark"><i class="ti-facebook"></i></a></li>
                        <li class="list-inline-item"><a href="#" class="text-dark"><i class="ti-twitter-alt"></i></a></li>
                        <li class="list-inline-item"><a href="#" class="text-dark"><i class="ti-linkedin"></i></a></li>
                        <li class="list-inline-item"><a href="#" class="text-dark"><i class="ti-github"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="text-center">
        <p>Copyright ©<script>
                var CurrentYear = new Date().getFullYear()
                document.write(CurrentYear)
            </script> ARiF | Masadi Dwi Kurniawan</p>
    </div>
</footer>

<!-- jQuery -->
<script src="<?= base_url() ?>assets/plugins/jQuery/jquery.min.js"></script>
<!-- Bootstrap JS -->
<script src="<?= base_url() ?>assets/plugins/bootstrap/bootstrap.min.js"></script>
<!-- slick slider -->
<script src="<?= base_url() ?>assets/plugins/slick/slick.min.js"></script>
<!-- masonry -->
<script src="<?= base_url() ?>assets/plugins/masonry/masonry.js"></script>
<!-- instafeed -->
<script src="<?= base_url() ?>assets/plugins/instafeed/instafeed.min.js"></script>
<!-- smooth scroll -->
<script src="<?= base_url() ?>assets/plugins/smooth-scroll/smooth-scroll.js"></script>
<!-- headroom -->
<script src="<?= base_url() ?>assets/plugins/headroom/headroom.js"></script>
<!-- reading time -->
<script src="<?= base_url() ?>assets/plugins/reading-time/readingTime.min.js"></script>

<!-- Main Script -->
<script src="<?= base_url() ?>assets/js/script.js"></script>

</body>

</html>