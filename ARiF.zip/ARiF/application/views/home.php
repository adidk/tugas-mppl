<!-- featured post -->
<section>
    <div class="container-fluid p-sm-0">
        <div class="row featured-post-slider">
            <?php foreach ($random_user as $ru) : ?>
                <div class="col-lg-3 col-sm-6 mb-2 mb-lg-0 px-1">
                    <article class="card bg-dark text-center text-white border-0 rounded-0">
                        <img class="card-img rounded-0 img-fluid w-100" src="<?= base_url() ?>images/user/<?= $ru['image'] ?>" alt="post-thumb">
                        <div class="card-img-overlay">
                            <div class="card-content">
                                <p class="text-uppercase">Food</p>
                                <h4 class="card-title mb-4"><a class="text-white" href="#"><?= $ru['name'] ?></a></h4>
                                <a class="btn btn-outline-light" href="#">Visit</a>
                            </div>
                        </div>
                    </article>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<!-- /featured post -->

<!-- blog post -->
<section class="section">
    <div class="container">
        <?= $this->session->flashdata('message'); ?>
        <div class="row masonry-container">
            <?php foreach ($post as $pst) : ?>
                <div class="col-lg-4 col-sm-6 mb-5">
                    <article class="text-center">
                        <img class="img-fluid mb-4" src="<?= base_url() ?>images/post/<?= $pst['gambar'] ?>" alt="post-thumb">
                        <p class="text-uppercase mb-2"><?= $pst['name'] ?></p>
                        <h4 class="title-border"><a class="text-dark" href="blog-single.html"><?= $pst['menu_name'] ?></a></h4>
                        <p><?= $pst['caption'] ?></p>
                        <p>Diposting <?php echo date('m/d/Y', $pst['d_created']) ?></p>
                    </article>
                </div>
            <?php endforeach; ?>
        </div>
        <!-- <div class="row">
            <div class="col-12">
                <nav>
                    <ul class="pagination justify-content-center align-items-center">
                        <li class="page-item">
                            <span class="page-link">&laquo; Previous</span>
                        </li>
                        <li class="page-item active">
                            <span class="page-link">01</span>
                        </li>
                        <li class="page-item"><a class="page-link" href="#">02</a></li>
                        <li class="page-item"><a class="page-link" href="#">03</a></li>
                        <li class="page-item"><a class="page-link" href="#">04</a></li>
                        <li class="page-item"><a class="page-link" href="#">05</a></li>
                        <li class="page-item"><a class="page-link" href="#">06</a></li>
                        <li class="page-item">
                            <a class="page-link" href="#">Next &raquo;</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div> -->
    </div>
</section>
<!-- /blog post -->

<!-- instagram -->
<section>
    <div class="container-fluid px-0">
        <div class="row no-gutters instagram-slider" id="instafeed" data-userId="4044026246" data-accessToken="4044026246.1677ed0.8896752506ed4402a0519d23b8f50a17"></div>
    </div>
</section>
<!-- /instagram -->