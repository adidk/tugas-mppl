<?php
defined('BASEPATH') or exit('No direct script access allowed');

class post_model extends CI_Model

{
    public function getdata()
    {
        $this->db->select('*');
        $this->db->from('post');
        $this->db->join('user', 'user.id=post.user_id');
        return $query = $this->db->get()->result_array();
    }
}
