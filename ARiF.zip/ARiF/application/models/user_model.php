<?php
defined('BASEPATH') or exit('No direct script access allowed');

class user_model extends CI_Model

{
    public function get_random()
    {
        $query = "SELECT * FROM user
                    ORDER BY RAND()
                    LIMIT 5";
        return $this->db->query($query)->result_array();
    }
}
