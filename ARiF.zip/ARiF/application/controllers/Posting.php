<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Posting extends CI_Controller
{

    public function index()
    {
        $this->load->model('user_model');

        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['judul'] = "ARiF | Review Food";

        $this->form_validation->set_rules('menu_name', 'Menu Name', 'required|trim');
        $this->form_validation->set_rules('caption', 'Caption', 'required|trim');
        // $this->form_validation->set_rules('image', 'Gambar', 'required|trim');
        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('posting', $data);
            $this->load->view('templates/footer', $data);
        } else {

            $upload_image = $_FILES['image']['name'];

            if ($upload_image) {
                $config['upload_path']          = './images/post/';
                $config['allowed_types']        = 'gif|jpg|png|JPG|PNG';
                $config['max_size']             = 6291;

                $this->load->library('upload', $config);

                if ($this->upload->do_upload('image')) {
                    $new_image = $this->upload->data('file_name');
                    $this->db->set('gambar', $new_image);
                    $this->db->set('user_id', $data['user']['id'], true);
                    $this->db->set('menu_name', $this->input->post('menu_name'), true);
                    $this->db->set('caption', $this->input->post('caption'), true);
                    $this->db->set('d_created', time(), true);
                    $this->db->insert('post');
                    $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
menu berhasil ditambahkan</div>');
                    redirect('home');
                } else {
                    echo $this->upload->display_errors();
                    $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">
            menu tidak ditambahkan</div>');
                }
            }
        }
    }
}
